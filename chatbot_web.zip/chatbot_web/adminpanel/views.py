from django.shortcuts import render, redirect
from django.http import HttpResponse
import csv
import sqlite3
from datetime import datetime
from langchain.vectorstores import Chroma
from langchain.embeddings import OpenAIEmbeddings
from django.contrib.auth.models import User
from django.utils.dateparse import parse_datetime
from .models import UsageHistory

embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")
database = Chroma(persist_directory="./database", embedding_function=embeddings)

def admin_home(request):
    return render(request, 'adminpanel/admin_home.html')

def usage_history(request):
    if request.method == 'POST':
        start_date = parse_datetime(request.POST.get('start_date'))
        end_date = parse_datetime(request.POST.get('end_date'))
        filtered_history = UsageHistory.objects.filter(timestamp__range=(start_date, end_date))
    else:
        filtered_history = UsageHistory.objects.all()
    return render(request, 'adminpanel/usage_history.html', {'usage_history': filtered_history})

def db_manage(request):
    conn = sqlite3.connect('./database/chroma.sqlite3')
    cursor = conn.cursor()
    cursor.execute("PRAGMA table_info(embedding_fulltext_search_content)")
    columns = cursor.fetchall()
    conn.close()

    column_names = [col[1] for col in columns]  # Extract column names
    correct_column = 'c0'  # Assume 'string_value' is correct; adjust based on inspection

    if correct_column not in column_names:
        return HttpResponse(f"Column {correct_column} not found in the database.")

    conn = sqlite3.connect('./database/chroma.sqlite3')
    cursor = conn.cursor()
    cursor.execute(f"SELECT id, {correct_column} FROM embedding_fulltext_search_content")
    documents = cursor.fetchall()
    conn.close()

    if request.method == 'POST' and request.FILES.get('csv_file'):
        csv_file = request.FILES['csv_file']
        if not csv_file.name.endswith('.csv'):
            return HttpResponse("Invalid file format. Please upload a CSV file.")
        
        csv_data = csv.reader(csv_file.read().decode('utf-8').splitlines())
        for row in csv_data:
            document = row[1]
            database.add_texts([document])
        
        return redirect('db_manage')

    return render(request, 'adminpanel/db_manage.html', {'documents': documents})

def remove_document(request, doc_id):
    conn = sqlite3.connect('./database/chroma.sqlite3')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM embedding_fulltext_search_content WHERE id=?", (doc_id,))
    conn.commit()
    conn.close()
    return redirect('db_manage')

def vector_db_query(request):
    if request.method == 'POST':
        query = request.POST.get('query')
        results = database.similarity_search(query, k=10)
        return render(request, 'adminpanel/vector_db_query.html', {'results': results})
    return render(request, 'adminpanel/vector_db_query.html')

def user_list(request):
    users = User.objects.all().order_by('-date_joined')
    return render(request, 'adminpanel/sign_list.html', {'users': users})
