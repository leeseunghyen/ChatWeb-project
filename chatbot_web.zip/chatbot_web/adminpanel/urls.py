from django.urls import path
from . import views

urlpatterns = [
    path('', views.admin_home, name='admin_home'),
    path('usage-history/', views.usage_history, name='usage_history'),
    path('vector-db-query/', views.vector_db_query, name='vector_db_query'),
    path('user-list/', views.user_list, name='user_list'),
    path('db-manage/', views.db_manage, name='db_manage'),
    path('remove-document/<int:doc_id>/', views.remove_document, name='remove_document'),
]