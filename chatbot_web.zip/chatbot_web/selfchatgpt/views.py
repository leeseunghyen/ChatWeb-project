from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.utils import timezone
from langchain.chat_models import ChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
import logging
from adminpanel.models import UsageHistory
from .models import Conversation, Message
from django.http import HttpResponseForbidden

logger = logging.getLogger(__name__)

embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")
database = Chroma(persist_directory="./database", embedding_function=embeddings)
memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

qa_chain = ConversationalRetrievalChain.from_llm(
    llm=ChatOpenAI(model="gpt-3.5-turbo"),
    retriever=database.as_retriever(search_kwargs={"k": 3}),
    memory=memory
)

def is_admin(user):
    return user.is_authenticated and user.username == 'admin' and user.check_password('aivle0534')

@login_required
@user_passes_test(is_admin)
def admin_panel(request):
    return render(request, 'adminpanel/admin_home.html')

@login_required
def index(request):
    conversations = Conversation.objects.filter(user=request.user).order_by('-created_at')
    if conversations.exists():
        conversation = conversations.first()
    else:
        conversation = Conversation.objects.create(user=request.user)
    chat_history = conversation.messages.all()
    return render(request, 'selfchatgpt/index.html', {'chat_history': chat_history, 'conversation': conversation, 'conversations': conversations})

@login_required
def conversation_detail(request, pk):
    conversation = get_object_or_404(Conversation, pk=pk, user=request.user)
    messages = conversation.messages.all().order_by('timestamp')
    return render(request, 'selfchatgpt/conversation_detail.html', {'conversation': conversation, 'messages': messages})

@login_required
def chat(request, conversation_id):
    conversation = get_object_or_404(Conversation, id=conversation_id, user=request.user)
    try:
        query = request.POST.get('question')
        if query:
            timestamp = timezone.localtime(timezone.now())
            chat_history = [{"role": "user" if msg.sender == "user" else "assistant", "content": msg.text} for msg in conversation.messages.all()]
            result = qa_chain({"question": query, "chat_history": chat_history})
            
            answer = result['answer']
            
            Message.objects.create(conversation=conversation, timestamp=timestamp, sender='user', text=query)
            Message.objects.create(conversation=conversation, timestamp=timestamp, sender='bot', text=answer)

            UsageHistory.objects.create(user=request.user, question=query, answer=answer, timestamp=timestamp)
        else:
            logger.warning("No question provided.")
            return redirect('conversation_detail', pk=conversation_id)
    except Exception as e:
        logger.error(f"Error during chat processing: {e}")
        return redirect('conversation_detail', pk=conversation_id)
    
    return redirect('conversation_detail', pk=conversation_id)



@login_required
def reset_log(request, conversation_id):
    conversation = get_object_or_404(Conversation, id=conversation_id, user=request.user)
    conversation.messages.all().delete()
    return redirect('conversation_detail', pk=conversation_id)

@login_required
def history_view(request):
    chat_history = request.session.get('chat_history', [])
    return render(request, 'selfchatgpt/history.html', {'chat_history': chat_history})

@login_required
def conversation_list(request):
    conversations = Conversation.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'selfchatgpt/conversation_list.html', {'conversations': conversations})

@login_required
def new_message(request, pk):
    conversation = get_object_or_404(Conversation, pk=pk, user=request.user)
    if request.method == 'POST':
        text = request.POST.get('text')
        Message.objects.create(conversation=conversation, sender='user', text=text)
        return redirect('conversation_detail', pk=pk)
    return render(request, 'selfchatgpt/new_message.html', {'conversation': conversation})

@login_required
def new_conversation(request):
    conversation = Conversation.objects.create(user=request.user)
    return redirect('conversation_detail', pk=conversation.pk)

@login_required
def delete_conversation(request, pk):
    conversation = get_object_or_404(Conversation, pk=pk, user=request.user)
    if request.method == 'POST':
        conversation.delete()
        return redirect('index')
    return HttpResponseForbidden()

@login_required
def delete_selected_conversations(request):
    if request.method == 'POST':
        conversation_ids = request.POST.getlist('conversations')
        conversations = Conversation.objects.filter(id__in=conversation_ids, user=request.user)
        conversations.delete()
        return redirect('index')
    return HttpResponseForbidden()

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                if is_admin(user):
                    return redirect('/') 
                return redirect('/')
            else:
                messages.error(request, 'Invalid username or password.')
        else:
            messages.error(request, 'Invalid username or password.')
    else:
        form = AuthenticationForm()
    return render(request, 'selfchatgpt/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('/')

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('/')
    else:
        form = UserCreationForm()
    return render(request, 'selfchatgpt/signup.html', {'form': form})

def signup_success(request):
    return render(request, '/')

def signup_log(request):
    username = request.GET.get('username')
    password = request.GET.get('password')
    return render(request, 'selfchatgpt/signup_log.html', {'username': username, 'password': password})
