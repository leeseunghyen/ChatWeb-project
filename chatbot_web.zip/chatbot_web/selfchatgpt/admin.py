from django.contrib import admin
from django.urls import path

from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma

# Register your models here.
