from django.urls import path
from django.contrib import admin
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('chat/<int:conversation_id>/', views.chat, name='chat'),
    path('reset/<int:conversation_id>/', views.reset_log, name='reset_log'),
    path('conversation/list/', views.index, name='conversation_list'),
    path('conversation/<int:pk>/', views.conversation_detail, name='conversation_detail'),
    path('conversation/new/', views.new_conversation, name='new_conversation'),
    path('conversation/delete/<int:pk>/', views.delete_conversation, name='delete_conversation'),
    path('conversations/delete_selected/', views.delete_selected_conversations, name='delete_selected_conversations'),  # Add this line
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('signup/', views.signup_view, name='signup'),
    path('signup/success/', views.signup_success, name='signup_success'),
    path('adminpanel/', views.admin_panel, name='admin_panel'),
]
